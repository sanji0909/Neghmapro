package com.example.naghma

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

data class NaghmaTrack(
    val uri: String,
    val title: String,
    val artist: String = "Unknown artist",
    val artwork: String = "",
    val licenseUrl: String = "",
    val source: String = "local"
) {
    fun key(): String = uri
    fun toJson(): JSONObject = JSONObject()
        .put("uri", uri).put("title", title).put("artist", artist)
        .put("artwork", artwork).put("licenseUrl", licenseUrl).put("source", source)

    companion object {
        fun fromJson(o: JSONObject) = NaghmaTrack(
            o.optString("uri"), o.optString("title", "Track"),
            o.optString("artist", "Unknown artist"), o.optString("artwork", ""),
            o.optString("licenseUrl", ""), o.optString("source", "local")
        )
    }
}

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val queue = mutableListOf<NaghmaTrack>()
    private val favorites = mutableListOf<NaghmaTrack>()
    private val playlists = linkedMapOf<String, MutableList<NaghmaTrack>>()
    private var currentTrack: NaghmaTrack? = null
    private var activePlaylist: String? = null

    private lateinit var status: TextView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var art: ImageView
    private lateinit var playButton: Button
    private lateinit var favoriteButton: TextView
    private lateinit var queueCount: TextView
    private lateinit var progress: SeekBar
    private lateinit var currentTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var library: LinearLayout
    private lateinit var playlistContainer: LinearLayout
    private lateinit var searchPanel: LinearLayout
    private lateinit var searchResults: LinearLayout
    private lateinit var heroCard: View
    private lateinit var visualizerBars: LinearLayout
    private var visualizerAnimators = mutableListOf<ValueAnimator>()
    private var heroPulse: AnimatorSet? = null
    private var playPulse: ObjectAnimator? = null
    private var qualityPulse: ObjectAnimator? = null
    private lateinit var query: EditText
    private lateinit var clientId: EditText
    private val prefs by lazy { getSharedPreferences("naghma_library_v1", MODE_PRIVATE) }

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && p.duration > 0) {
                progress.max = 1000
                progress.progress = ((p.currentPosition.toDouble() / p.duration) * 1000).toInt()
                currentTime.text = formatTime(p.currentPosition)
                totalTime.text = formatTime(p.duration)
            }
            handler.postDelayed(this, 500)
        }
    }

    private val pickAudio = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {}
            val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Local track"
            queue.add(NaghmaTrack(uri.toString(), name, source = "local"))
        }
        saveLibrary()
        updateQueueCount()
        playTrack(queue.lastIndex)
        status.text = "${uris.size} ملف/ملفات تزادو للـ Queue"
        renderQueue()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        title = findViewById(R.id.trackTitle)
        artist = findViewById(R.id.artistName)
        art = findViewById(R.id.albumArt)
        heroCard = findViewById(R.id.heroCard)
        visualizerBars = findViewById(R.id.visualizerBars)
        playButton = findViewById(R.id.playPauseButton)
        favoriteButton = findViewById(R.id.favoriteButton)
        favoriteButton.setOnClickListener { toggleFavorite() }
        queueCount = findViewById(R.id.queueCount)
        progress = findViewById(R.id.progressSeek)
        currentTime = findViewById(R.id.currentTime)
        totalTime = findViewById(R.id.totalTime)
        library = findViewById(R.id.libraryContainer)
        playlistContainer = findViewById(R.id.playlistContainer)
        searchPanel = findViewById(R.id.searchPanel)
        searchResults = findViewById(R.id.searchResults)
        query = findViewById(R.id.searchQuery)
        clientId = findViewById(R.id.clientId)

        loadLibrary()
        player = ExoPlayer.Builder(this).build().also { exo ->
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playButton.text = if (isPlaying) "Ⅱ  PAUSE" else "▶  PLAY"
                    if (isPlaying) {
                        startVisualizer()
                        startHeroPulse()
                    } else {
                        stopVisualizer()
                        stopHeroPulse()
                    }
                    animateTap(playButton)
                }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val index = exo.currentMediaItemIndex
                    if (index in queue.indices) showTrack(queue[index])
                    updateQueueCount()
                }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_ENDED) status.text = "Queue salat."
                }
                override fun onPlayerError(error: PlaybackException) {
                    status.text = "Playback error: ${error.errorCodeName}"
                }
            })
        }

        findViewById<Button>(R.id.pickAudioButton).setOnClickListener {
            pickAudio.launch(arrayOf("audio/*"))
        }
        findViewById<Button>(R.id.searchOpenButton).setOnClickListener {
            searchPanel.visibility = if (searchPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        findViewById<Button>(R.id.searchButton).setOnClickListener { searchJamendo() }
        playButton.setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        findViewById<Button>(R.id.nextButton).setOnClickListener { player?.seekToNextMediaItem() }
        findViewById<Button>(R.id.previousButton).setOnClickListener {
            player?.let { if (it.currentPosition > 3000) it.seekTo(0) else it.seekToPreviousMediaItem() }
        }
        findViewById<Button>(R.id.showQueueButton).setOnClickListener { renderQueue() }
        findViewById<Button>(R.id.showFavoritesButton).setOnClickListener { renderFavorites() }
        findViewById<Button>(R.id.createPlaylistButton).setOnClickListener { createPlaylistDialog() }
        progress.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = player ?: return
                    if (p.duration > 0) p.seekTo((p.duration * value / 1000L))
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        renderQueue()
        renderPlaylists()
        updateQueueCount()
        handler.post(tick)
    }

    private fun toMediaItem(track: NaghmaTrack): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title).setArtist(track.artist)
            .apply { if (track.artwork.isNotBlank()) setArtworkUri(Uri.parse(track.artwork)) }
            .build()
        return MediaItem.Builder().setUri(track.uri).setMediaMetadata(metadata).build()
    }

    private fun playTrack(index: Int) {
        if (index !in queue.indices) return
        val p = player ?: return
        currentTrack = queue[index]
        showTrack(queue[index])
        p.setMediaItems(queue.map { toMediaItem(it) }, index, 0L)
        p.prepare()
        p.play()
        activePlaylist?.let { saveLibrary() }
        renderQueue()
    }

    private fun showTrack(track: NaghmaTrack) {
        currentTrack = track
        heroCard.animate().cancel()
        heroCard.alpha = 0.78f
        heroCard.translationY = 10f
        heroCard.animate().alpha(1f).translationY(0f).setDuration(260)
            .setInterpolator(AccelerateDecelerateInterpolator()).start()
        title.text = track.title
        artist.text = track.artist + if (track.source == "jamendo") " • Jamendo" else " • Local library"
        favoriteButton.text = if (favorites.any { it.key() == track.key() }) "♥" else "♡"
        animateArtwork()
        art.setImageResource(android.R.drawable.ic_media_play)
        if (track.artwork.startsWith("https://")) {
            io.execute {
                try {
                    val conn = URL(track.artwork).openConnection() as HttpURLConnection
                    conn.connectTimeout = 7000
                    conn.readTimeout = 7000
                    val bitmap = conn.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                    conn.disconnect()
                    if (bitmap != null) runOnUiThread { art.setImageBitmap(bitmap) }
                } catch (_: Exception) {}
            }
        }
    }

    private fun toggleFavorite() {
        val track = currentTrack ?: run {
            Toast.makeText(this, "شغّل أغنية الأول", Toast.LENGTH_SHORT).show()
            return
        }
        val existing = favorites.indexOfFirst { it.key() == track.key() }
        if (existing >= 0) favorites.removeAt(existing) else favorites.add(track)
        saveLibrary()
        favoriteButton.text = if (existing >= 0) "♡" else "♥"
        animateTap(favoriteButton)
        status.text = if (existing >= 0) "تحيدات من Favorites" else "تزادت لـ Favorites"
    }

    private fun createPlaylistDialog() {
        val input = EditText(this).apply { hint = "مثلاً: Chill / Workout" }
        AlertDialog.Builder(this).setTitle("New playlist").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty() && !playlists.containsKey(name)) {
                    playlists[name] = mutableListOf()
                    saveLibrary()
                    renderPlaylists()
                    status.text = "تصاوبات Playlist: $name"
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun renderQueue() {
        val p = player
        val currentIndex = p?.currentMediaItemIndex ?: -1
        renderTrackList(queue, "Queue خالية. زِد ملفات محلية أو قلب فالموسيقى.", true, currentIndex)
        updateQueueCount()
    }

    private fun renderFavorites() {
        renderTrackList(favorites, "مازال ما عندك حتى Favorite. ضغط على ♡ وانت كتسمع.", false)
    }

    private fun renderTrackList(tracks: List<NaghmaTrack>, emptyText: String, showRemove: Boolean, currentIndex: Int = -1) {
        library.removeAllViews()
        if (tracks.isEmpty()) {
            library.addView(TextView(this).apply {
                text = emptyText; setTextColor(0xFFA7ABB3.toInt()); setPadding(4, 14, 4, 14)
            })
            return
        }
        tracks.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(8, 8, 8, 8)
                setBackgroundColor(if (index == currentIndex) 0xFF242A21.toInt() else 0xFF17191D.toInt())
            }
            val label = TextView(this).apply {
                text = "${if (index == currentIndex) "♫ " else ""}${track.title}\n${track.artist}"
                setTextColor(0xFFF5F5F5.toInt())
                textSize = 14f
                setPadding(8, 4, 4, 4)
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val play = Button(this).apply {
                text = "▶"
                setOnClickListener {
                    if (showRemove) playTrack(index) else {
                        queue.clear(); queue.addAll(tracks)
                        playTrack(index)
                    }
                }
            }
            row.addView(play)
            if (showRemove) {
                val remove = Button(this).apply {
                    text = "×"
                    setOnClickListener {
                        if (index < queue.size) {
                            queue.removeAt(index)
                            saveLibrary()
                            player?.let { p2 ->
                                if (queue.isEmpty()) p2.clearMediaItems()
                                else if (index == currentIndex) playTrack(index.coerceAtMost(queue.lastIndex))
                                else p2.setMediaItems(queue.map { toMediaItem(it) }, p2.currentMediaItemIndex.coerceIn(0, queue.lastIndex), p2.currentPosition)
                            }
                            renderQueue()
                        }
                    }
                }
                row.addView(remove)
            } else {
                val add = Button(this).apply {
                    text = "+"
                    setOnClickListener {
                        queue.add(track)
                        saveLibrary()
                        updateQueueCount()
                        renderQueue()
                        status.text = "تزادت للـ Queue"
                    }
                }
                row.addView(add)
            }
            library.addView(row)
        }
    }

    private fun renderPlaylists() {
        playlistContainer.removeAllViews()
        if (playlists.isEmpty()) return
        playlistContainer.addView(TextView(this).apply {
            text = "YOUR PLAYLISTS"; setTextColor(0xFFB8F36B.toInt()); textSize = 13f
            setPadding(0, 18, 0, 8)
        })
        playlists.forEach { (name, tracks) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            val button = Button(this).apply {
                text = "$name (${tracks.size})"
                setOnClickListener { renderTrackList(tracks, "Playlist خالية. زِد ليها أغاني من Favorites أو Queue.", false) }
            }
            row.addView(button, LinearLayout.LayoutParams(0, -2, 1f))
            val addCurrent = Button(this).apply {
                text = "+ Current"
                setOnClickListener {
                    currentTrack?.let { if (tracks.none { t -> t.key() == it.key() }) tracks.add(it) }
                    saveLibrary(); renderPlaylists()
                }
            }
            row.addView(addCurrent)
            val playAll = Button(this).apply {
                text = "▶"
                setOnClickListener {
                    if (tracks.isNotEmpty()) {
                        queue.clear(); queue.addAll(tracks); activePlaylist = name; playTrack(0)
                    }
                }
            }
            row.addView(playAll)
            playlistContainer.addView(row)
        }
    }

    private fun updateQueueCount() {
        queueCount.text = "♫  QUEUE ${queue.size}"
        queueCount.animate().cancel()
        queueCount.scaleX = 0.94f
        queueCount.scaleY = 0.94f
        queueCount.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun startVisualizer() {
        stopVisualizer()
        val ids = intArrayOf(R.id.bar1, R.id.bar2, R.id.bar3, R.id.bar4, R.id.bar5)
        ids.forEachIndexed { index, id ->
            val bar = findViewById<View>(id)
            val density = resources.displayMetrics.density
            val heights = intArrayOf(15, 26, 19, 30, 16)
            val animator = ValueAnimator.ofInt(
                (7 * density).toInt().coerceAtLeast(5),
                (heights[index] * density).toInt(),
                ((9 + index % 3 * 3) * density).toInt(),
                ((19 + index % 2 * 5) * density).toInt()
            )
            animator.duration = 300L + index * 75L
            animator.startDelay = index * 35L
            animator.repeatCount = ValueAnimator.INFINITE
            animator.repeatMode = ValueAnimator.REVERSE
            animator.interpolator = AccelerateDecelerateInterpolator()
            animator.addUpdateListener { value ->
                val params = bar.layoutParams
                params.height = value.animatedValue as Int
                bar.layoutParams = params
                bar.alpha = 0.65f + ((value.animatedValue as Int) % 5) / 10f
            }
            animator.start()
            visualizerAnimators.add(animator)
        }
        visualizerBars.animate().alpha(1f).setDuration(180).start()
    }

    private fun stopVisualizer() {
        visualizerAnimators.forEach { it.cancel() }
        visualizerAnimators.clear()
        visualizerBars.animate().alpha(0.45f).setDuration(220).start()
        val ids = intArrayOf(R.id.bar1, R.id.bar2, R.id.bar3, R.id.bar4, R.id.bar5)
        ids.forEachIndexed { index, id ->
            val bar = findViewById<View>(id)
            val params = bar.layoutParams
            params.height = ((8 + index % 3 * 3) * resources.displayMetrics.density).toInt()
            bar.layoutParams = params
            bar.alpha = 0.75f
        }
    }

    private fun startHeroPulse() {
        stopHeroPulse()
        val scaleX = ObjectAnimator.ofFloat(heroCard, View.SCALE_X, 1f, 1.014f, 1f).apply {
            duration = 850
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        val scaleY = ObjectAnimator.ofFloat(heroCard, View.SCALE_Y, 1f, 1.014f, 1f).apply {
            duration = 850
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        heroPulse = AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        playPulse = ObjectAnimator.ofFloat(playButton, View.ALPHA, 1f, 0.72f, 1f).apply {
            duration = 650
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        qualityPulse = ObjectAnimator.ofFloat(findViewById(R.id.qualityLabel), View.ALPHA, 1f, 0.5f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun stopHeroPulse() {
        heroPulse?.cancel()
        heroPulse = null
        playPulse?.cancel()
        playPulse = null
        qualityPulse?.cancel()
        qualityPulse = null
        heroCard.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        playButton.animate().alpha(1f).setDuration(160).start()
        findViewById<View>(R.id.qualityLabel)?.animate()?.alpha(1f)?.setDuration(160)?.start()
    }

    private fun animateTap(view: View) {
        view.animate().cancel()
        view.scaleX = 0.88f
        view.scaleY = 0.88f
        view.rotation = -3f
        view.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(260)
            .setInterpolator(AccelerateDecelerateInterpolator()).start()
    }

    private fun animateArtwork() {
        art.animate().cancel()
        art.alpha = 0.25f
        art.scaleX = 0.88f
        art.scaleY = 0.88f
        art.rotation = -5f
        art.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setDuration(520)
            .setInterpolator(AccelerateDecelerateInterpolator()).start()
    }

    private fun saveLibrary() {
        val q = JSONArray(); queue.forEach { q.put(it.toJson()) }
        val f = JSONArray(); favorites.forEach { f.put(it.toJson()) }
        val p = JSONObject()
        playlists.forEach { (name, tracks) ->
            val arr = JSONArray(); tracks.forEach { arr.put(it.toJson()) }; p.put(name, arr)
        }
        prefs.edit().putString("queue", q.toString()).putString("favorites", f.toString())
            .putString("playlists", p.toString()).apply()
    }

    private fun loadLibrary() {
        try {
            val q = JSONArray(prefs.getString("queue", "[]"))
            for (i in 0 until q.length()) queue.add(NaghmaTrack.fromJson(q.getJSONObject(i)))
            val f = JSONArray(prefs.getString("favorites", "[]"))
            for (i in 0 until f.length()) favorites.add(NaghmaTrack.fromJson(f.getJSONObject(i)))
            val p = JSONObject(prefs.getString("playlists", "{}"))
            val keys = p.keys()
            while (keys.hasNext()) {
                val name = keys.next()
                val arr = p.getJSONArray(name)
                val tracks = mutableListOf<NaghmaTrack>()
                for (i in 0 until arr.length()) tracks.add(NaghmaTrack.fromJson(arr.getJSONObject(i)))
                playlists[name] = tracks
            }
        } catch (_: Exception) {
            queue.clear(); favorites.clear(); playlists.clear()
        }
    }

    private fun searchJamendo() {
        val term = query.text.toString().trim()
        val id = clientId.text.toString().trim()
        if (term.isEmpty() || id.isEmpty()) {
            Toast.makeText(this, "دخل اسم الأغنية وJamendo client_id", Toast.LENGTH_SHORT).show()
            return
        }
        status.text = "كنقلبو فالمكتبة المفتوحة..."
        searchResults.removeAllViews()
        io.execute {
            var conn: HttpURLConnection? = null
            try {
                val endpoint = "https://api.jamendo.com/v3.0/tracks/?client_id=${URLEncoder.encode(id, "UTF-8")}&format=json&limit=20&search=${URLEncoder.encode(term, "UTF-8")}&audioformat=mp31"
                conn = URL(endpoint).openConnection() as HttpURLConnection
                conn.connectTimeout = 12000; conn.readTimeout = 12000
                if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val tracks = json.optJSONArray("results")
                runOnUiThread {
                    searchResults.removeAllViews()
                    if (tracks == null || tracks.length() == 0) {
                        status.text = "ما لقيناش نتائج. جرّب كلمات أخرى."
                        return@runOnUiThread
                    }
                    for (i in 0 until tracks.length()) {
                        val item = tracks.getJSONObject(i)
                        val track = NaghmaTrack(
                            uri = item.optString("audio", ""),
                            title = item.optString("name", "Track"),
                            artist = item.optString("artist_name", "Artist"),
                            artwork = item.optString("image", ""),
                            licenseUrl = item.optString("license_ccurl", ""),
                            source = "jamendo"
                        )
                        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 8, 4, 8) }
                        row.addView(TextView(this).apply {
                            text = "${track.title}\n${track.artist}"
                            setTextColor(0xFFF5F5F5.toInt()); textSize = 14f
                        })
                        row.addView(Button(this).apply {
                            text = "▶ Play"
                            isEnabled = track.uri.startsWith("https://")
                            setOnClickListener {
                                queue.add(track); saveLibrary(); playTrack(queue.lastIndex)
                                status.text = if (track.licenseUrl.isNotBlank()) "راجع ترخيص المسار: ${track.licenseUrl}" else "راجع شروط استعمال المسار"
                            }
                        })
                        searchResults.addView(row)
                    }
                    status.text = "لقينا ${tracks.length()} نتيجة. تحقق من ترخيص كل مسار قبل إعادة التوزيع."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "فشل البحث: ${e.message ?: "network error"}" }
            } finally { conn?.disconnect() }
        }
    }

    private fun formatTime(ms: Long): String {
        if (ms < 0) return "0:00"
        val seconds = ms / 1000
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
        stopVisualizer()
        stopHeroPulse()
    }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        stopVisualizer()
        stopHeroPulse()
        player?.release(); player = null
        io.shutdownNow()
        super.onDestroy()
    }
}
