# Naghma Pro v0.5 — Pulse Motion Edition

- Strong animated visualizer bars with staggered timings.
- Player card breathing pulse while playback is active.
- Play button and Hi-Fi label pulse.
- Album art enters with fade, scale and tilt.
- Buttons respond with scale and rotation.
- Animations stop when playback pauses or the app leaves foreground.
- Fixes the favorite button view type to match the redesigned layout.

## Code on the Go
Extract the ZIP, open it as a Gradle project, Sync and build a debug APK. If your IDE needs different pinned Gradle/AGP/Kotlin/Media3 versions, keep the versions from a generated project that builds and copy the updated app files/resources. Source only: not yet built or tested in Code on the Go.


## v0.6 Neon Pulse edition
- Neon cyan / violet visual direction, refreshed hero/artwork/chip surfaces.
- Keeps the native Kotlin + Media3 player and playback animations.
- Removed duplicate animation method definitions discovered during polish.
- Source archive only; build and device testing are still required in Code on the Go.


## Build APK online (no PC needed locally)

This project includes a GitHub Actions workflow at `.github/workflows/android.yml`.
Upload this project to a GitHub repository from your phone, then open the repository's
**Actions** tab and run **Build Naghma Pro APK**. When the workflow finishes, open its
run, find **Artifacts**, and download `Naghma-Pro-debug-APK`. Extract the downloaded
artifact ZIP to get the `.apk`, then install it on your Android device.

This workflow has been added but has NOT been run here; the APK is not yet built or verified.
